extern long int count;
